package pe.edu.upeu.bibfx.controller;

import javafx.fxml.FXML;
import javafx.scene.control.TabPane;
import org.springframework.stereotype.Controller;

@Controller
public class MainController {

    @FXML
    private TabPane tabPane;

    @FXML
    public void initialize() {
        // Inicialización de la interfaz principal
    }

    @FXML
    private void handleLibrosTab() {
        tabPane.getSelectionModel().select(0);
    }

    @FXML
    private void handleUsuariosTab() {
        tabPane.getSelectionModel().select(1);
    }

    @FXML
    private void handlePrestamosTab() {
        tabPane.getSelectionModel().select(2);
    }
} 