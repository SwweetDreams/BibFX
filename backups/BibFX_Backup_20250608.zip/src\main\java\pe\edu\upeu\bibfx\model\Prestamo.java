package pe.edu.upeu.bibfx.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "prestamos")
public class Prestamo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "libro_id", nullable = false)
    @NotNull(message = "El libro es obligatorio")
    private Libro libro;

    @ManyToOne
    @JoinColumn(name = "usuario_id", nullable = false)
    @NotNull(message = "El usuario es obligatorio")
    private Usuario usuario;

    @NotNull(message = "La fecha de préstamo es obligatoria")
    private LocalDateTime fechaPrestamo;

    private LocalDateTime fechaDevolucion;
    private LocalDateTime fechaDevolucionReal;
    private String estado; // PRESTADO, DEVUELTO, VENCIDO
    private String observaciones;
} 