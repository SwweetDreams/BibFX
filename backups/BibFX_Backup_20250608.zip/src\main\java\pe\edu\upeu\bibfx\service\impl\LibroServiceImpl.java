package pe.edu.upeu.bibfx.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pe.edu.upeu.bibfx.model.Libro;
import pe.edu.upeu.bibfx.repository.LibroRepository;
import pe.edu.upeu.bibfx.service.LibroService;
import jakarta.persistence.EntityNotFoundException;

@Service
public class LibroServiceImpl implements LibroService {

    @Autowired
    private LibroRepository libroRepository;

    @Override
    @Transactional
    public Libro save(Libro libro) {
        if (libroRepository.existsByIsbn(libro.getIsbn())) {
            throw new IllegalArgumentException("Ya existe un libro con ese ISBN");
        }
        return libroRepository.save(libro);
    }

    @Override
    @Transactional
    public Libro update(Long id, Libro libro) {
        Libro existingLibro = libroRepository.findById(id)
            .orElseThrow(() -> new EntityNotFoundException("Libro no encontrado"));
        
        if (!existingLibro.getIsbn().equals(libro.getIsbn()) && 
            libroRepository.existsByIsbn(libro.getIsbn())) {
            throw new IllegalArgumentException("Ya existe un libro con ese ISBN");
        }

        libro.setId(id);
        return libroRepository.save(libro);
    }

    @Override
    @Transactional
    public void delete(Long id) {
        if (!libroRepository.existsById(id)) {
            throw new EntityNotFoundException("Libro no encontrado");
        }
        libroRepository.deleteById(id);
    }

    @Override
    public Libro findById(Long id) {
        return libroRepository.findById(id)
            .orElseThrow(() -> new EntityNotFoundException("Libro no encontrado"));
    }

    @Override
    public Page<Libro> findAll(Pageable pageable) {
        return libroRepository.findAll(pageable);
    }

    @Override
    public Page<Libro> findByTitulo(String titulo, Pageable pageable) {
        return libroRepository.findByTituloContainingIgnoreCase(titulo, pageable);
    }

    @Override
    public Page<Libro> findByAutor(String autor, Pageable pageable) {
        return libroRepository.findByAutorContainingIgnoreCase(autor, pageable);
    }

    @Override
    public Page<Libro> findByCategoria(String categoria, Pageable pageable) {
        return libroRepository.findByCategoriaContainingIgnoreCase(categoria, pageable);
    }

    @Override
    public boolean existsByIsbn(String isbn) {
        return libroRepository.existsByIsbn(isbn);
    }
} 