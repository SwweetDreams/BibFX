package pe.edu.upeu.bibfx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibFxApplicationTests {

	@Test
	void contextLoads() {
	}

}
